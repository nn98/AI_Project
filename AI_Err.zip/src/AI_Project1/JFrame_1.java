package AI_Project1;

import javax.swing.JFrame;

// 2. ������ ��üȭ
public class JFrame_1 extends JFrame {
	public JFrame_1(String t) {
		super(t);
		setTitle("Title");
		setSize(300,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	// ���� ��üȭ
	public void run() {
		setVisible(true);
	}
}
