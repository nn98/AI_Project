package AI_Project1;

import javax.swing.JFrame;

public class SwingTest {

	public static void main(String[] args) {
		// 1. �⺻ ���� �׽�Ʈ - �ּ�ó��
//		JFrame f=new JFrame("Title");
//		f.setSize(300,300);
//		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		f.setVisible(true);
		
		// 3. 
//		JFrame_2 f=new JFrame_2();
//		f.run();
		
		// 4.
//		new JFrame_3();
		
		//5.
		new TargetFrame();
	}

}
